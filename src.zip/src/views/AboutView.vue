<template>
  <div class="about">
    <h1>This is an about page</h1>
	<!-- item 就是我们遍历的那个一个值 arr里面每一个值  index 就是我们的下标 -->
	<!-- key要加上去  key 尽量要唯一的，特别是增删改 要唯一 只是简单的遍历 -->
	<h1 v-for="(item,index) in arr" key="index">{{item}}</h1>
	
	<!-- 使用v-show v-if 他们的共同作用就是 显示和隐藏元素 -->
	<div v-if="show">if控制</div>
	<div v-show="show">show控制</div>
	
	<!-- 区别：v-show 是通过样式display none block 显示和隐藏元素 v-if是整个元素移除或者重新渲染-->
	<!-- v-if消耗性能更大    频繁切换的时候使用v-show 不频繁使用的时候使用v-if -->
	<button @click="show=!show">点击修改show值</button>
	
	<div>总价格{{allPrice}}</div>
	
	<button @click="count=2">点击修改count值</button>
	
	<input type="text" v-model="allPrice">
	
	<div class="test">测试</div>
	
	<van-button type="primary">主要按钮</van-button>
	<van-button type="success">成功按钮</van-button>
	<van-button type="default">默认按钮</van-button>
	<van-button type="warning">警告按钮</van-button>
	<van-button type="danger">危险按钮</van-button>

  </div>
 
</template>

<script>

// 注意我们接收路径上面的参数的  useRoute
import {useRoute} from "vue-router"

import {reactive, toRefs,computed, watch, watchEffect, onBeforeMount, onMounted} from "vue"

import axios from 'axios'
export default {
	setup(){
		
		   axios({
		        method: 'get',   //方式有两种 get /post
		        url: `https://apis.netstart.cn/xpc/home/config`, //页面路径
		            //参数 如果   params:  query
		      })
		        .then((res) => { // res后面请求回来的一个结果
		          //获取文章视频
		          console.log('res', res)
		        })
		        .catch((err) => {})   //请失败后的处理结果
		
		
		
		
		
		//类似我们之前学习的uniapp的onLoad
		console.log("我进来，会被马上执行");
		
		onBeforeMount(()=>{
			console.log("我被渲染之前");
		})
		
		onMounted(()=>{
			console.log("我被渲染之后");
		})
		
		
		
		
		let Route = useRoute();
		
		console.log("Route",Route.query);
		
		
		// v-for v-if v-show
		let data = reactive({
			arr:["周星驰","刘德华","薛之谦","坤哥"],
			show:true,
			price:648,
			count:1
		})
		
		//定义一个新值 计算属性 是形成一个新的值 这个值是由多个值构造而成 多个值中其中一个发生改变 新的值也会跟着改变
		
		// let allPrice=computed(()=>{
		// 	//价格*数量=总价格
		// 	console.log("我又计算了");
		// 	return data.price * data.count
		// })
		
		let allPrice = computed({
			//读取
			get(){
			//价格*数量=总价格
			return data.price * data.count
			},
			//当我们的总价格allprice被修改时 set会跟着修改
			set(value){
				console.log("value",value);
			}
		})
		
		// //监听属性 监听某个值变化 如果这个值发生变化时 这个回调函数会被执行
		// // 三个参数  第一个参数就是我们想要监听的属性 第二个参数就是回调函数 第三个参数  immediate:true直接执行一次  可写可不写
		// watch(()=>data.count,(newValue,oldValue)=>{
		// 	console.log('newvalue',newValue);
		// 	console.log('oldvalue',oldValue);
		// },{immediate:true})
		//比较智能 没有说监听哪一个属性 只有我们里面使用的变量发生改变时才会去执行
		//第一个的时候也会被执行
		watchEffect(()=>{
			let test = data.count
			console.log('我被执行了1111',test);
		})
		
		return{
			...toRefs(data),
			allPrice
		}
	}
	
}
</script>

<style>
	.test{
		width: 100px;
		height: 100px;
		background: pink;
	}
	
	
</style>
