<template>
	<!-- 主要vue3有vue2的区别就是 它不需要根标签包住 -->
	测试页面
	<!-- 用之前那的div h2 span -->
<!-- 	<div>名字：{{name}}</div>
	<div>名字person：{{person.test}}</div>
	<div>年龄：{{age}}</div>
	<button @click="changeName">点击去修改年龄</button> -->
	{{name}}
	
	<button @click="toAbout">跳转about页面</button>
</template>


<script>
	// 引入ref函数  reactive函数   弄一个很像之前data的方式
	import { ref,reactive,toRefs} from "vue"
	
	// 引入一个useRouter
	
	import {useRouter} from 'vue-router'
	
	export default {
		//语法糖
		setup(){
			
			// 要做跳转的时候要加上这个变量
			let Router = useRouter();
			
			let data = reactive({
				name:"靓仔",
				age:199,
				sex:"不明"
			})
			
			let toAbout=()=>{
				// 第一种 普通跳转  push() 里面的参数是有不一样的 可以直接放我们想要跳转的路径
				//Router.push('/about');
				//Router.push({path:'/about'});
				// 第二种 携带参数query携带的参数过去 是一个对象
				Router.push({path:"/about",query:{name:"坤哥",age:18}})
				
			}
			
			// 声明一个变量
			// let name = "我坤哥";
			
			// //我们想要有响应式 要引入ref
			// let age=ref(18);
			
			// // 定义对象的时候使用
			// let person = reactive({
			// 	test:"reactive的test"
			// })
			// let changeName=()=>{
			// 	name = "小黑子";
			// 	//注意家value 这个是ref 有的东西
			// 	age.value = 99;
			// 	person.test = "修改"
			// 	console.log('age',age);
			// 	console.log('name',name);
			// 	console.log('person',person);
			// }
			// 声明的变量或者是方法是需要被return上去 在我们template使用
			return{
				//data
				...toRefs(data),
				toAbout
				// person,
				// name,
				// age,
				// changeName
			}
		}
	
	}
</script>

<style>
</style>