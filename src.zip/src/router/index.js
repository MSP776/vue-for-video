import { createRouter, createWebHistory } from 'vue-router'

// 引入就马上加载 60个页面 1个页面要1s 我们要等60s
import HomeView from '../views/HomeView.vue'

const routes = [
  {
    path: '/', //自定义路径 想要跳转的路径
    name: 'home', //自定名字
    component: HomeView  //指向你想要去的页面
  },
  {
    path: '/about', //注意一个点 不要出现大写
    name: 'about',

    // route level code-splitting
    // this generates a separate chunk (about.[hash].js) for this route
    // which is lazy-loaded when the route is visited.
	// 路由懒加载    只有我们去访问about页面的时候 我们才去加载这个文件
    component: () => import(/* webpackChunkName: "about" */ '../views/AboutView.vue')
  },
  {
    path: '/test', //注意一个点 不要出现大写
    name: 'test',
	// 别名
	//alias:"/bieming",
	//重定向 原本我想去访问/test Test.vuw 结果他出现重定向 那么我们就去找路径/about
	//redirect:"/about",
    // route level code-splitting
    // this generates a separate chunk (about.[hash].js) for this route
    // which is lazy-loaded when the route is visited.
  	// 路由懒加载    只有我们去访问about页面的时候 我们才去加载这个文件
    component: () => import(/* webpackChunkName: "about" */ '../views/Test.vue')
  }
]

const router = createRouter({
  history: createWebHistory(process.env.BASE_URL),
  routes
})

export default router
